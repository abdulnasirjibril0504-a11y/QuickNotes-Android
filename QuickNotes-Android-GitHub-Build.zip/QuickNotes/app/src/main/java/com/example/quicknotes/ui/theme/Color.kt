package com.example.quicknotes.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimaryLight = Color(0xFF3F51B5)
val OnIndigoPrimaryLight = Color(0xFFFFFFFF)
val IndigoContainerLight = Color(0xFFE0E4FF)
val OnIndigoContainerLight = Color(0xFF001159)
val SurfaceLight = Color(0xFFFAF9FD)
val SurfaceContainerLowLight = Color(0xFFF3F3F8)
val OnSurfaceLight = Color(0xFF1A1B20)
val OnSurfaceVariantLight = Color(0xFF45464F)
val OutlineLight = Color(0xFF757680)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

val IndigoPrimaryDark = Color(0xFFBBC3FF)
val OnIndigoPrimaryDark = Color(0xFF08218A)
val IndigoContainerDark = Color(0xFF26389C)
val OnIndigoContainerDark = Color(0xFFE0E4FF)
val SurfaceDark = Color(0xFF121318)
val SurfaceContainerLowDark = Color(0xFF1A1B21)
val OnSurfaceDark = Color(0xFFE3E2E9)
val OnSurfaceVariantDark = Color(0xFFC5C6D0)
val OutlineDark = Color(0xFF8F909A)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)
