package com.example.quicknotes.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.quicknotes.ui.screens.HomeScreen
import com.example.quicknotes.ui.screens.NoteEditorScreen

private object Routes {
    const val HOME = "home"
    const val EDITOR = "editor/{noteId}"
    fun editor(noteId: Long = -1L) = "editor/$noteId"
}

@Composable
fun QuickNotesApp(viewModel: NotesViewModel) {
    val navController = rememberNavController()
    val notes by viewModel.notes.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    NavHost(
        navController = navController,
        startDestination = Routes.HOME
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                notes = notes,
                themeMode = themeMode,
                onCycleTheme = viewModel::cycleThemeMode,
                onAddNote = {
                    navController.navigate(Routes.editor(-1L))
                },
                onNoteClick = { noteId ->
                    navController.navigate(Routes.editor(noteId))
                },
                onDeleteNote = viewModel::deleteNote,
                onRestoreNote = viewModel::restoreNote
            )
        }

        composable(
            route = Routes.EDITOR,
            arguments = listOf(
                navArgument("noteId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val noteId = backStackEntry.arguments?.getLong("noteId") ?: -1L
            NoteEditorScreen(
                noteId = noteId,
                loadNote = viewModel::getNoteById,
                onSave = { title, content ->
                    viewModel.saveNote(
                        id = if (noteId > 0L) noteId else null,
                        title = title,
                        content = content
                    ) {
                        navController.popBackStack()
                    }
                },
                onDelete = {
                    if (noteId > 0L) {
                        viewModel.deleteNoteById(noteId) {
                            navController.popBackStack()
                        }
                    } else {
                        navController.popBackStack()
                    }
                },
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
