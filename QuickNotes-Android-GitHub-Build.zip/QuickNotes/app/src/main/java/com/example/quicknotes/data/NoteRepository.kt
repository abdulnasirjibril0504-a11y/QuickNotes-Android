package com.example.quicknotes.data

import kotlinx.coroutines.flow.Flow

class NoteRepository(private val noteDao: NoteDao) {
    val allNotes: Flow<List<Note>> = noteDao.getAllNotes()

    suspend fun getNoteById(id: Long): Note? = noteDao.getNoteById(id)

    suspend fun saveNote(id: Long?, title: String, content: String) {
        val trimmedTitle = title.trim()
        val trimmedContent = content.trim()
        if (trimmedTitle.isEmpty() && trimmedContent.isEmpty()) return

        val now = System.currentTimeMillis()
        if (id != null && id > 0L) {
            val existing = noteDao.getNoteById(id)
            if (existing != null) {
                noteDao.updateNote(
                    existing.copy(
                        title = trimmedTitle,
                        content = trimmedContent,
                        updatedAt = now
                    )
                )
                return
            }
        }

        noteDao.insertNote(
            Note(
                title = trimmedTitle,
                content = trimmedContent,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun restoreNote(note: Note) {
        noteDao.insertNote(note)
    }

    suspend fun deleteNote(note: Note) {
        noteDao.deleteNote(note)
    }

    suspend fun deleteNoteById(id: Long) {
        noteDao.deleteNoteById(id)
    }
}
