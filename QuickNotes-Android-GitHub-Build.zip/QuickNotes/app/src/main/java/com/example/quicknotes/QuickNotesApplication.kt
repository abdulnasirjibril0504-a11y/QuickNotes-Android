package com.example.quicknotes

import android.app.Application
import com.example.quicknotes.data.NoteDatabase
import com.example.quicknotes.data.NoteRepository

class QuickNotesApplication : Application() {
    val database: NoteDatabase by lazy {
        NoteDatabase.getDatabase(this)
    }

    val repository: NoteRepository by lazy {
        NoteRepository(database.noteDao())
    }
}
