package com.example.quicknotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.quicknotes.ui.NotesViewModel
import com.example.quicknotes.ui.NotesViewModelFactory
import com.example.quicknotes.ui.QuickNotesApp
import com.example.quicknotes.ui.ThemeMode
import com.example.quicknotes.ui.theme.QuickNotesTheme

class MainActivity : ComponentActivity() {
    private val viewModel: NotesViewModel by viewModels {
        val app = application as QuickNotesApplication
        NotesViewModelFactory(app.repository, app)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val darkTheme = when (themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            QuickNotesTheme(darkTheme = darkTheme) {
                QuickNotesApp(viewModel = viewModel)
            }
        }
    }
}
