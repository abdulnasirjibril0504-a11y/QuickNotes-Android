# Quick Notes (Android · Kotlin · Jetpack Compose)

A local-first Material 3 note-taking app for Android built with Kotlin, Jetpack Compose, Navigation Compose, and Room.

- **Package:** `com.example.quicknotes`
- **SDK:** `minSdk = 24`, `targetSdk = 34`, `compileSdk = 34`
- **Database:** Room (`quick_notes_db`)
- **Theme:** Material 3 with Light / Dark / System toggle and Android 12+ dynamic color

## Build Debug APK

Open the project root in a terminal (or Android Studio Terminal):

```bash
# macOS / Linux
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

> Note: If you extracted the source zip without a `gradle-wrapper.jar` binary, open the project once in Android Studio (which auto-syncs the Gradle wrapper) or run `gradle wrapper` first, then run `./gradlew assembleDebug`.

### Output APK Path

```
app/build/outputs/apk/debug/app-debug.apk
```

## Install on a Phone

### Option 1: Install via USB (ADB)
1. On your Android phone, open **Settings → About phone** and tap **Build number** 7 times to enable **Developer options**.
2. Open **Settings → System → Developer options** and enable **USB debugging**.
3. Connect the phone to your computer with a USB cable and tap **Allow** on the USB debugging prompt.
4. Run:
   ```bash
   adb devices
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

### Option 2: Copy the APK File to Your Phone
1. Copy `app/build/outputs/apk/debug/app-debug.apk` to your phone's **Downloads** folder (via USB file transfer, Google Drive, or Nearby Share).
2. Open the **Files** app on your phone and tap `app-debug.apk`.
3. If prompted, tap **Settings** and enable **Allow from this source** for your file manager.
4. Tap **Install**, then launch **Quick Notes**.
